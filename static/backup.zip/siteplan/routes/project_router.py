## Project router
# This route handles all project related requests 
import datetime
import json
from starlette.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse
from starlette_login.decorator import login_required
from decoRouter import Router
from modules.project import Project
from modules.employee import Employee
from modules.utils import today, timestamp, to_dollars, convert_timestamp
from config import TEMPLATES
from database import RedisCache

router = Router()

# Output:
# October 11, 2022


@router.POST('/new_project')
@login_required
async def new_project(request):    
    username =  request.user.username        
    async with request.form() as form:
        data = {
            "name": form.get('name'),
            "category": form.get('category'),
            "standard": form.get('standard'),
            "address": {
                "lot": form.get('lot'), 
                "street": form.get('standard'), 
                "town": form.get('standard'),
                "city_parish": form.get('city_parish'),
                "country": form.get('country', "Jamaica") 
            },
            "owner": {
            "name": form.get('owner'),
            "contact": None,
            "address": {"lot": None, "street": None, "town": None,"city_parish": None,"country": None, }
            },
            "admin": {
                "leader": form.get('lead'),
                "staff": {
                "accountant": None,
                "architect": None,
                "engineer":None,
                "quantitysurveyor": None,
                "landsurveyor": None,
                "supervisors": []
                }
            },
            "created_by": username
            

        }   
    p = Project(data=data)
    p.setup()
    p.runsetup() 
    new_project = await p.save()    
    return RedirectResponse(url=f'/project/{new_project.get("_id")}', status_code=303)
   

@router.GET('/projects')
@login_required
async def get_projects(request):    
    username =  request.user.username        
    p = await Project().all()        
    projects = [project for project in p.get('rows', []) if project.get('value').get("meta_data", {}).get("created_by") == username]
    return TEMPLATES.TemplateResponse('/project/projectsIndex.html',{
        'request': request,
        'projects': projects
    })


@router.get('/project/{id}')
@login_required
async def get_project(request):
    id = request.path_params.get('id')
    p = await Project().get(id=id)
    return TEMPLATES.TemplateResponse('/project/projectPage.html', 
                                      {
                                          "request": request, 
                                          "id": id, 
                                          "p": p
                                          })



# Project State 
@router.get('/project_state/{id}')
async def get_project_state(request):
    id = request.path_params.get('id')
    p = await Project().get(id=id)
    return HTMLResponse(f"""
                        <div class="uk-alert-primary" uk-alert>
                            <a href class="uk-alert-close" uk-close></a>
                            {p.get('state')}
                            </div>""")

# Project Events 
@router.get('/project_event/{id}')
async def get_project_event(request):
    id = request.path_params.get('id')
    p = await Project().get(id=id)
    return HTMLResponse(f"""
                        <div class="uk-alert-primary" uk-alert>
                            <a href class="uk-alert-close" uk-close></a>
                            {p.get('event')}
                            </div>""")


# Project Events 
@router.get('/project_activity/{id}')
async def get_project_activity(request):
    id = request.path_params.get('id')
    p = await Project().get(id=id)
    return TEMPLATES.TemplateResponse(
        "/project/activityLog.html", 
        {"request": request, "activity_log": p.get('activity_log')}
    )


## Project Jobs
@router.get('/project_jobs/{id}')
@login_required
async def get_project_jobs(request):
    id = request.path_params.get('id')
    p = await Project().get(id=id)
    jobs = p.get('tasks')
    
    return TEMPLATES.TemplateResponse(
        '/project/jobsIndex.html', 
        { "request": request, "p": p, "jobs": jobs }
        )


@router.get('/project_days/{id}')
async def get_project_days(request):
    id = request.path_params.get('id')
    p = await Project().html_days_page(id=id)
    return HTMLResponse(p)


@router.get('/project_workers/{id}/{filter}')
async def get_project_workers(request):
    id = request.path_params.get('id')
    filter = request.path_params.get('filter')
    p = await Project().get(id=id)
    e = await Employee().all_workers()
    workers = p.get('workers')
    categories = { worker.get('value').get('occupation') for worker in workers }
    if filter:
        if filter == 'all' or filter == 'None':            
            filtered = workers 
        else:
            filtered = [worker for worker in workers if worker.get("value").get("occupation") == filter]

    
    return  TEMPLATES.TemplateResponse('/project/projectWorkers.html', 
                                       {
                                           "request": request,
                                           "id": id,
                                           "p": p,
                                           "employees": e,
                                           "workers": workers,
                                           "categories": categories,
                                           "filter" : filter,
                                           "filtered": filtered

                                           
                                        })


# PROCESS RATES
@router.get('/project_rates/{id}')
async def get_project_rates(request):
    id = request.path_params.get('id')
    from modules.rate import Rate        
    industry_rates = await Rate().all_rates()
    p = await Project().get(id=id)
    
    return TEMPLATES.TemplateResponse('/project/rates/projectRates.html', 
        {
            "request": request,
            "p": {
                "_id": p.get('_id'),
                "name": p.get('name'),
                "rates": p.get('rates', [])
            },
            "industry_rates": industry_rates
        } )



@router.post('/add_worker_to_project')
@login_required
async def add_worker_to_project(request):
    async with request.form() as form:
        data = form.get('employee')
    idd = data.split('-')
    p = await Project().get(id=idd[0])
    employees = await Employee().all_workers()
    employee = [e for e in employees.get('rows') if e.get('id') == idd[1]][0]
    employee['id'] = data
    p['workers'].append(employee)
    e = await Employee().get_worker(id=idd[1])
    if idd[0] in e.get('jobs'):
        pass
    else:
        e['jobs'].append(idd[0])
        await Employee().update(data=e)
    await Project().update(p)
    return HTMLResponse(f"""<div uk-alert>
                            <a href class="uk-alert-close" uk-close></a>
                            <h3>Notice</h3>
                            <p>{employee.get('value').get('name')} is employed to Job {p.get('name')}.</p>
                            
                        </div>""")



@router.post('/update_project_standard/{id}')
@login_required
async def update_project_standard(request):
    id = request.path_params.get('id')    
    p = await Project().get(id=id)
    try:
        async with request.form() as form:
            standard = form.get('standard')
        if standard == None:
            p['standard'] = "imperial"
            await Project().update(data=p)
            return HTMLResponse("Imperial")
        else:
            p['standard'] = "metric"
            await Project().update(data=p)
            return HTMLResponse("Metric")
    except:
        pass



