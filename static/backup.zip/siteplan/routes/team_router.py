# Team Router 
from starlette.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse
from starlette_login.decorator import login_required
from decoRouter import Router
from modules.project import Project
from modules.employee import Employee
from config import TEMPLATES
from modules.utils import timestamp

router = Router()

# Employee Related routes  
@router.get('/team')
async def team(request): 
    return StreamingResponse(Employee().team_index_generator(), media_type="text/html")




@router.get('/team/{id}')
async def team_member(request): 
    id=request.path_params.get('id')
    e = await Employee().get_worker(id=request.path_params.get('id')) 
    jobs = []
    tasks = []
    async def get_jobs_details(job_id):
        if '-' in job_id:
            idd = job_id.split('-')
            project = await Project().get(id=idd[0])
            a_job = [job for job in project.get('tasks') if job.get('_id') == job_id][0]
            e_tasks = [task for task in a_job.get('tasks') if task.get('_id') in e.get('tasks')]
            if len(e_tasks) > 0:
                for etask in e_tasks:
                    tasks.append(etask)

            return  {
                    "project": project.get('name'),
                    "job_id": a_job.get('_id'),
                    "title": a_job.get('title')
                }
        else:
            return None
        
    for item in e.get('jobs', []):
        jobs_item = await get_jobs_details(job_id=item)
        if jobs_item:
            jobs.append(
               jobs_item
                 
                 )
    if len(jobs) > 0:
        e['jobs'] = jobs
    
    if len(tasks) > 0:
        e['tasks'] = tasks

    return TEMPLATES.TemplateResponse('/employee/employeeHomePage.html', {"request": request, "employee": e})

 
    

@router.get('/team_json/{id}')
async def team_json(request):  
  return JSONResponse( await Employee().get_worker(id=request.path_params.get('id')))



@router.post('/newworker')
@login_required
async def new_worker(request):
    payload = {}
    try:
        async with request.form() as form:            
            payload['name'] = form.get('name')
            payload['oc'] = form.get('oc')
            payload['sex'] = form.get('sex')
            payload['dob'] = form.get('dob')
            payload['height'] = form.get('height')
            payload['identity'] = form.get('identity')
            payload['id_type'] = form.get('id_type')
            payload['trn'] = form.get('trn')
            payload['occupation'] = form.get('occupation')
            payload['rating'] = form.get('rating')
            payload['imgurl'] = ""
            payload['address'] = {
                'lot': form.get('lot'),
                'street': form.get('street'),
                  'town': form.get('town'),
                   'city_parish': form.get('city_parish')
                  
                
                }
            payload['contact'] = {
                'tel': form.get('tel'),
                'mobile': form.get('mobile'),
                'email': form.get('email')
                
            }
            payload['account'] = {
                "bank": {
                "name": form.get('bank'),
                "branch": form.get('bank_branch'),
                "account": form.get('account_no'),
                "account_type": form.get('account_type')
                },
                "payments": [],
                "loans": []
                
            }
            payload["nok"] = {
                "name": form.get('kin_name'),
                "relation": form.get('kin_relation'),
                "address": form.get('kin_address'),
                "contact":  form.get('kin_contact')
            }
            payload[ "tasks"] = []
            payload["jobs"] = []
            payload["days"] =  []
            payload["earnings"] = []
            payload["state"] = {
                "active": True,
                "onleave": False,                
                "terminated": False
            },
            payload["event"] = {
                "started": None,
                "onleave":[] ,
                "restart": [],
                "terminated": None,
                "duration": 0
            },
            payload["reports"] = []
            
        ne = await Employee().save(data = payload)   

              
        return HTMLResponse(f"""<p class="bg-blue-800 text-white text-sm font-bold py-3 px-4 mx-5 my-2 rounded-md">{ne }</p>""")
    except Exception as e:
        return HTMLResponse(f"""<p class="bg-red-400 text-red-800 text-2xl font-bold py-3 px-4"> An error occured! ---- {str(e)}</p> """)

    finally:
        del(payload)
        


@router.post('/record_employee_loan/{id}')
async def record_employee_loan(request): 
    e = await Employee().get_worker(id=request.path_params.get('id')) 
    #return TEMPLATES.TemplateResponse('/employee/employeePage.html', {"request": request, "e": e})
    loan = {
        "id": timestamp(),
        "repayment": []
    }
    async with request.form() as form:
        for key, value in form.items():
            loan[key] = value 
        loan['amount'] = float(loan.get('amount'))    

    e['account']['loans'].append(loan)
    await Employee().update(data=e)
    return HTMLResponse(f"""{e['account']['loans']}""")


@router.get('/repay_employee_loan/{id}')
@router.post('/repay_employee_loan/{id}')
async def repay_employee_loan(request): 
    id=request.path_params.get('id')
    idd = id.split('_')
    employee = await Employee().get_worker(id=idd[0]) 
    
    loan = [item for item in employee.get('account').get('loans') if item.get('id') == int(idd[1])][0]
    if request.method == 'GET':
        form = f""" <form class="mx-auto flex w-full max-w-lg flex-col rounded-xl border border-border bg-backgroundSecondary p-4 sm:p-20">
           
          
            <div class="form-group">
                <div class="flex w-full flex-col gap-2">
                    <div class="form-field">
                        <label class="form-label">Date </label>
            
                        <input type="date"  name="date" class="input max-w-full" />
                        <label class="form-label">
                            <span class="form-label-alt">Please enter a valid date.</span>
                        </label>
                    </div>
                    <div class="form-field">
                        <label class="form-label">
                            <span>Amount</span>
                        </label>
                        <div class="form-control">
                            <input placeholder="Amount here" type="number" step="0.01" name="amount" class="input max-w-full" />
                        </div>
                    </div>
                    <div class="form-field pt-5">
                        <div class="form-control justify-between">
                            <button 
                                type="button" 
                                class="btn btn-primary w-full uk-modal-close"
                                hx-post="/repay_employee_loan/{id}"
                                hx-target="#message"
                            >Pay Amount</button>
                        </div>
                    </div>
                </div>
        </form>"""
    
    if request.method == 'POST':
        payment = { }
        async with request.form() as form:
            payment['date'] = form.get('date')
            payment['amount'] = float(form.get('amount')) 
            if payment.get('amount') == float(loan.get('amount')):
                payment['resolved'] = True
            else: 
                payment['resolved'] = False
                payment['ballance'] = float(loan.get('amount')) - payment.get('amount')
        loan["repayment"].append(payment)
        await Employee().update(data=employee)
        return HTMLResponse(f"""<div>{loan}</div>""")
    return HTMLResponse(f"""{form}""")






@router.get('/analytics')
async def analytics(request):
    t = f""" 
    <a class="uk-button uk-button-default" href="#modal-sections" uk-toggle>Open</a>

<div id="modal-sections" uk-modal>
    <div class="uk-modal-dialog">
        <button class="uk-modal-close-default" type="button" uk-close></button>
        <div class="uk-modal-header">
            <h2 class="uk-modal-title">Modal Title</h2>
        </div>
        <div class="uk-modal-body">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        </div>
        <div class="uk-modal-footer uk-text-right">
            <button class="uk-button uk-button-default uk-modal-close" type="button">Cancel</button>
            <button class="uk-button uk-button-primary" type="button">Save</button>
        </div>
    </div>
</div>
    
    <table class="uk-table uk-table-divider">
    <thead>
        <tr>
            <th>Table Heading</th>
            <th>Table Heading</th>
            <th>Table Heading</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Table Data</td>
            <td>Table Data</td>
            <td>Table Data</td>
        </tr>
        <tr>
            <td>Table Data</td>
            <td>Table Data</td>
            <td>Table Data</td>
        </tr>
        <tr>
            <td>Table Data</td>
            <td>Table Data</td>
            <td>Table Data</td>
        </tr>
    </tbody>
</table>
"""
    return HTMLResponse(t)